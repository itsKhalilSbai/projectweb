<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>list of books</title>
    
    <link href="file.css" rel="stylesheet" type="text/css" />
</head>
     <body>
         <section>

             <h1 > S O R R Y !! no media right now</h1>
             <input id="btn" type="button"  value="Click here to go back.." onclick="check()">
            <img class="error" src="images/error.PNG" alt="error404">
         </section>
 
     

<script>
         function check(){
        
         if( confirm("do you want to go back ? ") ){
            window.location.replace("index.php");
         }
         else 
         window.location.replace("index.php");
     }
</script>

     </body>
 </html>