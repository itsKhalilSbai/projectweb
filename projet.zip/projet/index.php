<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>library</title>
    <link rel="stylesheet" href="style.css" />
    <link href="style2.css" rel="stylesheet" type="text/css" />
    <link href="style3.css" rel="stylesheet" type="text/css" />
</head>
<body>
<header>
  <?php  session_start(); ?>
    <div>
            <a href="index.php">
                <img id="logopage" src="images/logo.png" alt="logo E-library" />
            </a>
    </div>

 <!-- navigation bar-->       
        <nav>
            <ul> 
              <li class="x"> 
                  <a href="login.html">Login <span style="color: black" style="font-weight: bold">/</span> Register</a> 
              </li>
              <!-- ********* -->
              <li class="x">
                  <a href="contact.php">Contact</a>
              </li>
              <!-- ********* --> 
              <li id="alone">
                    <a href="list.php">Books & Media</a>
                    <ul>
                        <li class="block">
                            <a href="book.php"> Books </a>  
                        </li> 
                        <li class="block">
                            <a href="media.php"> Media </a>
                        </li>
                    </ul>
              </li> 
              <li class="x">
                  <a href="logout.php">logout</a>
              </li>

            </ul>
        </nav>
        
    </header>
 
  <?php 
 
  include("database.php"); 

  ?>


<div class="banner" >
        
    
        <div class="banneritem"> <img src="images/banner1.png" alt="banner1" width="700px" height="300px" ></div>
        <div class="banneritem"> <img src="images/banner2.png" alt="banner2" width="700px" height="300px"></div>
        <div class="banneritem"> <img src="images/banner3.png" alt="banner3" width="700px" height="300px"></div>
</div>

       
        

    
<!-- list items-->
      <section class="listofbooks">

          <article class="books">
              <img class="imgs" src="images/book1.PNG" alt="image of book">
              <?php $i = 1; 
                        $q = $db->query('select nom from books where isbn =  '.$i.'   ');
                        $i = $i+1;
                        $data = $q->fetch();
                        $title = $data["nom"];
                        $_SESSION["title"] = $title;
          
          ?>
              
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>
              


          </article>

          <article class="books">
              <img class="imgs" src="images/book2.PNG" alt="image of book">
              
              <?php 

              $q = $db->query('select nom from books where isbn =  '.$i.'   ');
              $i = $i+1;
              $data = $q->fetch();
              $title = $data["nom"];  
              $_SESSION["title"] = $title;
              ?>
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>

          </article>

          <article  class="books">
              <img class="imgs" src="images/book3.PNG" alt="image of book">
              
              <?php 

              $q = $db->query('select nom from books where isbn =  '.$i.'   ');
              $i = $i+1;
              $data = $q->fetch();
              $title = $data["nom"]; 
              $_SESSION["title"] = $title; 
              ?>
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>


          </article>
          <article  class="books">
              <img class="imgs" src="images/book4.PNG" alt="image of book">
              
              <?php 

              $q = $db->query('select nom from books where isbn =  '.$i.'   ');
              $i = $i+1;
              $data = $q->fetch();
              $title = $data["nom"];  
              $_SESSION["title"] = $title;
              ?>
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>


          </article>
          <article  class="books">
              <img class="imgs" src="images/book5.PNG" alt="image of book">
              
              <?php 

              $q = $db->query('select nom from books where isbn =  '.$i.'   ');
              $i = $i+1;
              $data = $q->fetch();
              $title = $data["nom"];  
              $_SESSION["title"] = $title;
              ?>
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>


          </article>
          <article  class="books">
              <img class="imgs" src="images/book6.PNG" alt="image of book">
              
              <?php 
               include("database.php"); 

              $q = $db->query('select nom from books where isbn =  '.$i.'   ');
              $i = $i+1;
              $data = $q->fetch();
              $title = $data["nom"];  
              $_SESSION["title"] = $title;
              ?>
              <h2> <?php echo $title; ?></h2>
              <p> description : this book is awesome, get it now </p>
              <a href="emprunt.php"> emprunter</a>


          </article>

          

    

      </section>
     <hr style="background-color: orange;">
       <section class="listofbooks" >
       <article  class="books">
          
            <p> click in the <span style="color: black;"> middle </span>  to see list of all books  <a href="list.php "> 
            <video id="vid1" width="150" height="170" autoplay loop >
                <source src="images/more.mp4" type="video/mp4">
                        Your browser does not support the video tag.
            </video> 
                <script>
                     document.getElementById('vid1').currentTime = 1;
                </script>     
            
            </a></p>


          </article>
       </section>
       

     <footer>
     <div class="border"> <h1> Follow us : </h1>
      <ul> 
      <li class="i"><a href="https://www.facebook.com"> <img src="images/facebook.png" alt="logo fb" width="100" height="100"></a></li>
      <li><a href="https://www.instagram.com"> <img src="images/insta.jpg" alt="logo insta" width="100" height="100"></a></li>
      <li><a href="https://www.youtube.com"> <img src="images/youtube.png" alt="logo youtube" width="100" height="100"></a></li>
      </ul>
      </div>
      

      <!---->
     


    




     </footer>



<script src="banner.js"></script>   
</body>
</html>