<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<?php 
 include("database.php"); 
 session_start();

  
              
                $uname = $_SESSION["username"];
                $numberdays = 0;
// function verify here :

              function verify() {
                  if($_SESSION["username"] ) {
                      return true;     
                  }
                   else return false;  
              }

              function traiter(){
                 if(verify()) {
                include("database.php");

                  $req =$db->prepare("insert into emprunts values(?,?,?);
                  ");

                  $reponse = $req->execute(array($_SESSION["title"],$uname, $numberdays));

                header('location:index.php');
                 }
                 else echo 'NO user found!';
                 header('location:index.php');
                 
              }
              
  
          
                    

               

echo 'please specify amount of days. between 1 and 30 days';
echo ' <form action="emprunt.php" method="get"> '; 

              
              echo '<br>';
              echo '<input type="text" name="result">';
              echo '<input type="submit" value="submit result" onclick="traiter()">' ; 
     echo '</form>';
     $numberdays = $_GET["result"];
     echo 'problem occured. you ll be redirected after 5 seconds..';
     header('refresh:5; URL=index.php');
              ?>
</body>
</html>