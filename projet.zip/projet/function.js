function verif(){
    if(confirm("are the informations correct ?")) {
     window.location.replace("index.php");
 }
 else window.location.replace("index.php");
 
 }

function ajouterlivre(){
    
}


