<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <input type="button" value="ajouter livre" onclick="ajouterlivre">
    <input type="button" value="supprimer livre" onclick="supprimerlivre">

<?php
     include("database.php"); 

   $nom = "book8";
   $aut = 'author1';
   $cat = "horror";
     $d = $db->query('insert into books(nom,auteur,categorie) values('.$nom.','.$aut.','.$cat. ')' );
     

     function ajouterlivre(){
        include("database.php"); 
        $d = $db->query('insert into books(nom,auteur,categorie) values('.$nom.','.$aut.','.$cat. ')' );
     
    }

    function supprimerlivre(){
        include("database.php"); 
        $d = $db->query('delete from books where $nom ='.$nom );
     
    }
?>
</body>
</html>