<?php

try{
  $db = new PDO('mysql:host =localhost; dbname=library; charset = UTF8', 'root', '');
}
catch(Exception $e){
    die('error : '.$e->getMessage());
}


?>