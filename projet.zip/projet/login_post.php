<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

/*if(isset($_POST["username"])){
	setcookie("visiteur", $_POST["username"],Time()+3600*12);
}*/


    
    include("database.php"); 
    
   $username = $_POST["username"];
   $password =  $_POST["password"];


    $req = $db->query ("select * from users 
                        where username = '". $username. "' and password = '".$password."'
                    "); 

    $data = $req->fetch();



    if($data === false){
        echo '<script type="text/javascript">';
        echo ' if(confirm("USER NOT FOUND !!!") ==true) window.location = "login.html"; ';  // same as header() in php, window.location in javascript pour la redirection
        echo 'else alert("no data found.."); window.location = "login.html";';
        echo '</script>' ;       
        // header('Location: login.html');
        // die;

;
        
        
    }
    else if ($data["type"] === "membre")  {
                session_start();
                $_SESSION["username"]= $username;
                


                header("location:index.php");

                
            }
     

    else if ($data["type"] === "admin") 
                header("location: admin.php");


    else echo '';

    
     ?>
</body>
</html>