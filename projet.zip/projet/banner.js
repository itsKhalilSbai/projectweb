document.querySelectorAll(".banner").forEach((banner) => {
    const items = banner.querySelectorAll(".banneritem");
    const buttonsHtml = Array.from(items, () => {
      return `<span class="banner__button"></span>`;
    });
  
    banner.insertAdjacentHTML(
      "beforeend",
      `
          <div class="banner__nav">
              ${buttonsHtml.join("")}
          </div>
      `
    );
  
    const buttons = banner.querySelectorAll(".banner__button");
  
    buttons.forEach((button, i) => {
      button.addEventListener("click", () => {
      
        items.forEach((item) =>
          item.classList.remove("banneritem--selected")
        );
        buttons.forEach((button) =>
          button.classList.remove("banner__button--selected")
        );
  
        items[i].classList.add("banneritem--selected");
        button.classList.add("banner__button--selected");
      });
    });
  
    items[0].classList.add("banneritem--selected");
    buttons[0].classList.add("banner__button--selected");
  });
  