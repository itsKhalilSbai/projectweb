<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
include("database.php"); 
$name = $_POST["name"];
$prename = $_POST["prename"];
$usernom = $_POST["usernom"];
$pwd =  $_POST["pwd"];


// before insert search if username is unique  condition below (next )
// select username from users where username = $usernom              


$req = $db->query ("select username from users 
where username = '". $usernom. "' 
"); 

$data = $req->fetch();
if($data===false){


 $req = $db->prepare("insert into users(nom, prenom, username, password) values(?,?,?,?);
                 "); 
$reponse = $req->execute(array(  $_POST["name"],$_POST["prename"], $_POST["usernom"] , $_POST["pwd"] ));

header('location:user.php');

}
else{

    echo '<script type="text/javascript">';
    echo 'if(confirm("you tried connecting using an existing username, please try a different one..") ==true) window.location = "login_post2.html"; ';
    echo 'else alert("please try again or login"); window.location = "login_post2.html";';
    echo '</script>' ;
      
}

          //echo ' confirm("you tried connecting using an existing username, please try a different one..");';








 ?>  
</body>
</html>