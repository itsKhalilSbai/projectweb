<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link href="style4.css" rel="stylesheet" type="text/css" />
</head>
<body>
<section>
        <h1 style="color: gold;">CONTACT ME</h1>
<div id="down">     </div>

        
        <section class="login-box">
            <form >
                <div class="user-box">
                  <input type="email" name="" required="">
                  <label>email</label>
                </div>

                <div class="user-box">
                  <input type="text" name="" required="">
                  <label>subject</label>
                </div>

                <div class="user-box">
                    <textarea style="color: rgb(29, 31, 31); background-color: rgb(161, 211, 192);" rows="9" cols="38" placeholder="Enter your message"></textarea>
                  </div>

                <a href="index.php" onclick="verif()">
                  <span></span>
                  <span></span>
                  <span></span>
                  <span></span>
                  Envoyer
                </a>
              </form>
         
        </section>
    
    <script src="function.js"> </script>
</body>
</html>